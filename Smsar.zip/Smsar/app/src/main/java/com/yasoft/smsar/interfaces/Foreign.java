package com.yasoft.smsar.interfaces;



public interface Foreign {

    public void setData(int id, String city, String desc, String price);
}
